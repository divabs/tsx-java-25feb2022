package com.tsk_java.webhook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebhookApplicationTests {

	@Test
	void contextLoads() {
	}

}
